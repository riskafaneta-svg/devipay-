# Otak Flash AI (by Trav Team) - paket Capacitor + Android native

- Struktur Capacitor valid: package.json, capacitor.config.json, www/, android/
- Logika aplikasi ada di android/app/src/main/java/com/travteam/otakflash (Kotlin native).
- Versi mengikuti engine SwapLab: Capacitor 8.6.0, Java 21, Gradle 8.14.3.
