package com.travteam.otakflash

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager

    private var overlayView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var resultCard: View? = null
    private var tvResult: TextView? = null

    private var mediaProjection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var imageThread: HandlerThread? = null
    private var imageHandler: Handler? = null

    private val imageLock = Any()
    private var lastImage: Image? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDpi = 0

    private var serverUrl = ""
    private var authToken = ""
    private var isBusy = false

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Wajib dipanggil sebelum getMediaProjection() (Android 10+/14).
        startAsForeground()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = readResultData(intent)
        if (resultCode != Activity.RESULT_OK || data == null) {
            toast("Data izin perekaman layar tidak valid.")
            stopSelf()
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !android.provider.Settings.canDrawOverlays(this)
        ) {
            toast("Izin overlay belum diberikan.")
            stopSelf()
            return START_NOT_STICKY
        }

        authToken = intent.getStringExtra(EXTRA_TOKEN).orEmpty()
        serverUrl = intent.getStringExtra(EXTRA_URL).orEmpty().trimEnd('/')

        teardown()
        try {
            setupProjection(resultCode, data)
            showOverlay()
        } catch (e: Exception) {
            toast("Gagal memulai overlay: " + (e.message ?: "error"))
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readResultData(intent: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        }
    }

    // ------------------------------------------------------------ Notification

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Otak Flash AI",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Otak Flash AI aktif")
            .setContentText("Tombol mengambang siap digunakan.")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    // --------------------------------------------------------- MediaProjection

    private fun setupProjection(resultCode: Int, data: Intent) {
        readScreenSize()

        val thread = HandlerThread("OtakFlashImageThread").also { it.start() }
        imageThread = thread
        val handler = Handler(thread.looper)
        imageHandler = handler

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = manager.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("MediaProjection tidak tersedia")
        mediaProjection = projection

        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projectionCallback = callback
        // Wajib didaftarkan sebelum createVirtualDisplay() pada Android 14+.
        projection.registerCallback(callback, Handler(Looper.getMainLooper()))

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 3)
        imageReader = reader

        reader.setOnImageAvailableListener({ r ->
            val image = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (image != null) {
                synchronized(imageLock) {
                    lastImage?.close()
                    lastImage = image
                }
            }
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "OtakFlashCapture",
            screenWidth,
            screenHeight,
            screenDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )
    }

    @Suppress("DEPRECATION")
    private fun readScreenSize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            screenWidth = bounds.width()
            screenHeight = bounds.height()
        } else {
            val metrics = DisplayMetrics()
            windowManager.defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
        }
        screenDpi = resources.displayMetrics.densityDpi
    }

    // ----------------------------------------------------------------- Overlay

    @SuppressLint("InflateParams")
    private fun showOverlay() {
        val themedContext = ContextThemeWrapper(this, R.style.Theme_OtakFlashAI)
        val view = LayoutInflater.from(themedContext).inflate(R.layout.floating_layout, null)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 240
        }

        val btnFlash = view.findViewById<MaterialButton>(R.id.btnFlash)
        val btnClose = view.findViewById<MaterialButton>(R.id.btnClose)
        val card = view.findViewById<View>(R.id.resultCard)
        val result = view.findViewById<TextView>(R.id.tvResult)

        btnClose.setOnClickListener { stopSelf() }
        card.setOnClickListener { card.visibility = View.GONE }

        overlayView = view
        layoutParams = params
        resultCard = card
        tvResult = result

        attachDrag(btnFlash) { onFlashClicked() }

        windowManager.addView(view, params)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(handle: View, onClick: () -> Unit) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _, event ->
            val params = layoutParams
            val root = overlayView
            if (params == null || root == null) {
                return@setOnTouchListener false
            }
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) {
                        moved = true
                    }
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        try {
                            windowManager.updateViewLayout(root, params)
                        } catch (e: Exception) {
                            // view sudah dilepas
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        onClick()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun showResult(text: String) {
        resultCard?.visibility = View.VISIBLE
        tvResult?.text = text
    }

    // ------------------------------------------------------ Screenshot + Kirim

    private fun onFlashClicked() {
        if (isBusy) return
        isBusy = true

        serviceScope.launch {
            try {
                // Sembunyikan overlay agar tidak ikut terambil di screenshot.
                overlayView?.visibility = View.INVISIBLE
                delay(350)

                val base64 = withContext(Dispatchers.Default) { captureBase64() }
                overlayView?.visibility = View.VISIBLE

                if (base64 == null) {
                    showResult("Gagal mengambil screenshot.\n\nMembuka ChatGPT...")
                    openFallback()
                    return@launch
                }

                showResult("Menganalisis layar...")
                val result = withContext(Dispatchers.IO) { askAi(base64) }
                result.onSuccess { answer ->
                    showResult(answer)
                }.onFailure { error ->
                    showResult("Gagal: " + (error.message ?: "error") + "\n\nMembuka ChatGPT...")
                    openFallback()
                }
            } finally {
                overlayView?.visibility = View.VISIBLE
                isBusy = false
            }
        }
    }

    private fun captureBase64(): String? {
        val bitmap = synchronized(imageLock) {
            lastImage?.let { imageToBitmap(it) }
        } ?: return null

        val scaled = scaleDown(bitmap, MAX_SIDE)
        val output = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 75, output)
        if (scaled !== bitmap) {
            scaled.recycle()
        }
        bitmap.recycle()

        return Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val full = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            full.copyPixelsFromBuffer(buffer)

            val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
            if (cropped !== full) {
                full.recycle()
            }
            cropped
        } catch (e: Exception) {
            null
        }
    }

    private fun scaleDown(source: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(source.width, source.height)
        if (longest <= maxSide) return source
        val ratio = maxSide.toFloat() / longest.toFloat()
        val w = (source.width * ratio).toInt().coerceAtLeast(1)
        val h = (source.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, w, h, true)
    }

    private fun askAi(base64: String): Result<String> = runCatching {
        val payload = JSONObject()
            .put("image", base64)
            .put(
                "prompt",
                "Analisis screenshot ini. Jika ada soal atau pertanyaan, " +
                    "jawab dengan singkat dan jelas dalam Bahasa Indonesia."
            )
            .toString()

        val request = Request.Builder()
            .url("$serverUrl/ask-ai")
            .addHeader("Authorization", "Bearer $authToken")
            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("Server mengembalikan HTTP " + response.code)
            }
            parseAnswer(body)
        }
    }

    private fun parseAnswer(body: String): String {
        val text = try {
            val json = JSONObject(body)
            var found = ""
            for (key in listOf("answer", "response", "result", "message", "text")) {
                val value = json.optString(key)
                if (value.isNotEmpty()) {
                    found = value
                    break
                }
            }
            found.ifEmpty { body }
        } catch (e: Exception) {
            body
        }
        if (text.isBlank()) {
            throw IOException("Respons server kosong")
        }
        return text.trim()
    }

    private fun openFallback() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(FALLBACK_URL))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            toast("Tidak dapat membuka browser.")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
    }

    // ----------------------------------------------------------------- Cleanup

    private fun teardown() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // sudah dilepas
            }
        }
        overlayView = null
        resultCard = null
        tvResult = null
        layoutParams = null

        virtualDisplay?.release()
        virtualDisplay = null

        imageReader?.setOnImageAvailableListener(null, null)
        synchronized(imageLock) {
            lastImage?.close()
            lastImage = null
        }
        imageReader?.close()
        imageReader = null

        val projection = mediaProjection
        val callback = projectionCallback
        if (projection != null) {
            if (callback != null) {
                projection.unregisterCallback(callback)
            }
            projection.stop()
        }
        mediaProjection = null
        projectionCallback = null

        imageThread?.quitSafely()
        imageThread = null
        imageHandler = null
    }

    override fun onDestroy() {
        serviceScope.cancel()
        teardown()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TOKEN = "extra_token"
        const val EXTRA_URL = "extra_url"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "otak_flash_channel"
        private const val NOTIFICATION_ID = 1001
        private const val MAX_SIDE = 1280
        private const val FALLBACK_URL = "https://chat.openai.com"
    }
}
