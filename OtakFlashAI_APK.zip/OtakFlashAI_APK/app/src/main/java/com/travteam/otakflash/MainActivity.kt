package com.travteam.otakflash

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var config: ServerConfig
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnStartOverlay: Button
    private lateinit var btnServerSettings: Button
    private lateinit var tvStatus: TextView

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Lanjut ke tahap berikutnya apa pun hasilnya (notifikasi bersifat opsional).
            checkOverlayPermissionThenCapture()
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                requestScreenCapture()
            } else {
                toast("Izin overlay (tampil di atas aplikasi lain) diperlukan.")
            }
        }

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                startFloatingService(result.resultCode, data)
            } else {
                toast("Izin perekaman layar ditolak.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        config = ServerConfig(this)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnStartOverlay = findViewById(R.id.btnStartOverlay)
        btnServerSettings = findViewById(R.id.btnServerSettings)
        tvStatus = findViewById(R.id.tvStatus)

        btnLogin.setOnClickListener { doLogin() }
        btnStartOverlay.setOnClickListener { startOverlayFlow() }
        btnServerSettings.setOnClickListener { showServerSettingsDialog() }

        updateStatus()
    }

    // ------------------------------------------------------------------ Status

    private fun updateStatus() {
        val loggedIn = config.authToken.isNotEmpty()
        val loginText = if (loggedIn) "Status: sudah login" else "Status: belum login"
        tvStatus.text = loginText + "\nServer: " + config.serverUrl
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------------- Login

    private fun doLogin() {
        val username = etUsername.text.toString().trim()
        val password = etPassword.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            toast("Username dan password wajib diisi.")
            return
        }

        btnLogin.isEnabled = false
        tvStatus.text = "Memproses login..."

        val baseUrl = config.serverUrl
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { performLogin(baseUrl, username, password) }
            btnLogin.isEnabled = true
            result.onSuccess { token ->
                config.authToken = token
                updateStatus()
                toast("Login berhasil.")
            }.onFailure { error ->
                updateStatus()
                toast("Login gagal: " + (error.message ?: "terjadi kesalahan"))
            }
        }
    }

    private fun performLogin(baseUrl: String, username: String, password: String): Result<String> =
        runCatching {
            val payload = JSONObject()
                .put("username", username)
                .put("password", password)
                .toString()

            val request = Request.Builder()
                .url("$baseUrl/login")
                .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IOException("HTTP " + response.code)
                }
                val json = JSONObject(body)
                val token = json.optString("token").ifEmpty { json.optString("access_token") }
                if (token.isEmpty()) {
                    throw IOException("Token tidak ditemukan pada respons server")
                }
                token
            }
        }

    // ---------------------------------------------------------- Server Setting

    private fun showServerSettingsDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.server_settings, null)
        val etServerUrl = view.findViewById<EditText>(R.id.etServerUrl)
        etServerUrl.setText(config.serverUrl)

        MaterialAlertDialogBuilder(this)
            .setView(view)
            .setPositiveButton(R.string.btn_save) { _, _ ->
                val url = etServerUrl.text.toString().trim()
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    config.serverUrl = url
                    updateStatus()
                    toast("URL server disimpan.")
                } else {
                    toast("URL harus diawali http:// atau https://")
                }
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    // ----------------------------------------------------------- Start Overlay

    private fun startOverlayFlow() {
        if (config.authToken.isEmpty()) {
            toast("Silakan login terlebih dahulu.")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            checkOverlayPermissionThenCapture()
        }
    }

    private fun checkOverlayPermissionThenCapture() {
        if (Settings.canDrawOverlays(this)) {
            requestScreenCapture()
        } else {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun startFloatingService(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(this, FloatingService::class.java).apply {
            putExtra(FloatingService.EXTRA_TOKEN, config.authToken)
            putExtra(FloatingService.EXTRA_URL, config.serverUrl)
            putExtra(FloatingService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FloatingService.EXTRA_RESULT_DATA, data)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        toast("Overlay Otak Flash AI aktif.")
        moveTaskToBack(true)
    }
}
